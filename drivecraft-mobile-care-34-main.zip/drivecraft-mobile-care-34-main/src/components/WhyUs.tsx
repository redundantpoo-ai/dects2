import { motion } from "framer-motion";
import { MapPin, Heart, DollarSign, Clock } from "lucide-react";

const reasons = [
  {
    icon: MapPin,
    title: "Mobile Convenience",
    description:
      "We come to your home, office, or anywhere you park. No more waiting at the shop.",
  },
  {
    icon: Heart,
    title: "Experienced & Friendly",
    description:
      "Our mechanics treat your car like their own. Professional service with a personal touch.",
  },
  {
    icon: DollarSign,
    title: "Transparent Pricing",
    description:
      "No surprises, no hidden fees. You'll know exactly what you're paying for upfront.",
  },
  {
    icon: Clock,
    title: "Fast & Reliable",
    description:
      "Your time matters. We show up when we say we will and get the job done right.",
  },
];

const WhyUs = () => {
  return (
    <section className="py-24 bg-background">
      <div className="container">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block px-4 py-1.5 rounded-full bg-primary/10 text-primary font-semibold text-sm mb-4">
              Why DriveCraft?
            </span>
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6 leading-tight">
              Car Care That Fits{" "}
              <span className="text-gradient">Your Life</span>
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-8">
              We built DriveCraft because we know how frustrating traditional
              auto shops can be. Long waits, confusing pricing, and the hassle
              of arranging rides. We think you deserve better.
            </p>

            {/* Stats */}
            <div className="flex gap-8">
              <div>
                <div className="font-display text-4xl font-bold text-primary">
                  98%
                </div>
                <div className="text-sm text-muted-foreground">
                  Customer Satisfaction
                </div>
              </div>
              <div>
                <div className="font-display text-4xl font-bold text-primary">
                  15+
                </div>
                <div className="text-sm text-muted-foreground">
                  Years Experience
                </div>
              </div>
              <div>
                <div className="font-display text-4xl font-bold text-primary">
                  5k+
                </div>
                <div className="text-sm text-muted-foreground">
                  Services Completed
                </div>
              </div>
            </div>
          </motion.div>

          <div className="grid sm:grid-cols-2 gap-6">
            {reasons.map((reason, index) => (
              <motion.div
                key={reason.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="p-6 rounded-2xl bg-card border border-border/50 shadow-soft hover:shadow-card transition-shadow duration-300"
              >
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mb-4">
                  <reason.icon className="w-6 h-6 text-accent" />
                </div>
                <h3 className="font-display text-lg font-bold text-foreground mb-2">
                  {reason.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {reason.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhyUs;
