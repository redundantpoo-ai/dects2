import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Calendar, Truck, Smile, ArrowRight } from "lucide-react";

const steps = [
  {
    icon: Calendar,
    number: "01",
    title: "Book Your Spot",
    description:
      "Choose your service and pick a time that works for you. It takes less than 2 minutes.",
  },
  {
    icon: Truck,
    number: "02",
    title: "We Come to You",
    description:
      "Our certified mechanic arrives at your location — home, work, or anywhere convenient.",
  },
  {
    icon: Smile,
    number: "03",
    title: "Drive Happy",
    description:
      "Service complete, car ready, and you didn't have to lift a finger. That's the DriveCraft way.",
  },
];

const HowItWorks = () => {
  return (
    <section className="py-24 bg-gradient-hero relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-10 w-72 h-72 bg-accent rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent rounded-full blur-3xl" />
      </div>

      <div className="container relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-accent/20 text-accent font-semibold text-sm mb-4">
            How It Works
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-primary-foreground mb-4">
            Three Simple Steps to a Happy Car
          </h2>
          <p className="text-primary-foreground/70 text-lg">
            Getting your car serviced has never been easier. Here's how we make
            it happen.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8 relative">
          {/* Connector Line */}
          <div className="hidden md:block absolute top-24 left-1/6 right-1/6 h-0.5 bg-gradient-to-r from-transparent via-accent/30 to-transparent" />

          {steps.map((step, index) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="relative text-center"
            >
              <div className="relative inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-accent mb-6 shadow-glow">
                <step.icon className="w-8 h-8 text-accent-foreground" />
                <div className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-primary-foreground flex items-center justify-center">
                  <span className="font-display text-sm font-bold text-primary">
                    {step.number}
                  </span>
                </div>
              </div>

              <h3 className="font-display text-xl font-bold text-primary-foreground mb-3">
                {step.title}
              </h3>

              <p className="text-primary-foreground/70 leading-relaxed max-w-xs mx-auto">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center mt-16"
        >
          <Button variant="hero" size="xl">
            Get Started Now
            <ArrowRight className="w-5 h-5" />
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default HowItWorks;
