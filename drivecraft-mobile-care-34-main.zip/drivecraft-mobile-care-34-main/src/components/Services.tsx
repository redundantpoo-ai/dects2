import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Search, Droplets, Disc, ArrowRight } from "lucide-react";

const services = [
  {
    icon: Search,
    title: "Inspection",
    description:
      "Catch small problems before they become big ones. We'll make sure your ride is safe and road-ready.",
    features: ["Full diagnostic scan", "Safety check", "Detailed report"],
  },
  {
    icon: Droplets,
    title: "Oil Change",
    description:
      "Fresh oil, smooth engine, happy car. Quick, clean, and convenient — we come to you.",
    features: ["Premium oils", "Filter replacement", "Fluid top-off"],
  },
  {
    icon: Disc,
    title: "Brake Jobs",
    description:
      "From squeaks to full replacements, we'll stop your car safely so you can drive worry-free.",
    features: ["Pad & rotor service", "Brake fluid flush", "Safety inspection"],
  },
];

const Services = () => {
  return (
    <section className="py-24 bg-muted/50">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-2xl mx-auto mb-16"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-accent/10 text-accent font-semibold text-sm mb-4">
            Our Services
          </span>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Done Right, Wherever You Are
          </h2>
          <p className="text-muted-foreground text-lg">
            Professional auto care that comes to you. No shop visits, no waiting
            rooms — just quality service at your convenience.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="group relative bg-card rounded-2xl p-8 shadow-card hover:shadow-lg transition-all duration-300 border border-border/50"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-accent/5 rounded-bl-[100px] transition-all duration-300 group-hover:bg-accent/10" />
              
              <div className="relative">
                <div className="w-14 h-14 rounded-xl bg-gradient-accent flex items-center justify-center mb-6 shadow-glow">
                  <service.icon className="w-7 h-7 text-accent-foreground" />
                </div>

                <h3 className="font-display text-2xl font-bold text-foreground mb-3">
                  {service.title}
                </h3>

                <p className="text-muted-foreground mb-6 leading-relaxed">
                  {service.description}
                </p>

                <ul className="space-y-2 mb-6">
                  {service.features.map((feature) => (
                    <li
                      key={feature}
                      className="flex items-center gap-2 text-sm text-foreground"
                    >
                      <div className="w-1.5 h-1.5 rounded-full bg-accent" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <Button
                  variant="ghost"
                  className="group/btn p-0 h-auto text-accent hover:text-accent/80 hover:bg-transparent"
                >
                  Learn more
                  <ArrowRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-1" />
                </Button>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-12"
        >
          <Button variant="hero" size="lg">
            Schedule a Service
            <ArrowRight className="w-4 h-4" />
          </Button>
        </motion.div>
      </div>
    </section>
  );
};

export default Services;
